"""Authentication API contracts."""
from __future__ import annotations

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    tenant_id: str = "company-a"
    email: str
    password: str


class RegisterRequest(BaseModel):
    tenant_id: str = "company-a"
    email: str
    password: str = Field(..., min_length=8)
    role: str = Field(default="analyst", pattern="^(analyst|viewer)$")


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict[str, str]


class StatusUpdateRequest(BaseModel):
    status: str = Field(
        ...,
        pattern="^(open|acknowledged|in_progress|contained|resolved|closed|false_positive)$",
    )
