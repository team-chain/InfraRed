"""Ingestion package."""
