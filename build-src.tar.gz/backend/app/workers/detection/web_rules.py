"""WEB-001..007 rule evaluator for nginx access.log events.

WEB-001  Web Shell Access      /uploads/*.php|*.jsp + 200 -> single event trigger
WEB-002  Admin Path Scan       /admin|/login 30+ hits / 5 min from same IP
WEB-003  Automation Tool       curl/python-requests/wget UA -> single event trigger
WEB-004  404 Burst             50+ 404 responses / 5 min from same IP
WEB-005  SQL Injection         URL에 SQL 키워드/특수문자 패턴 감지
WEB-006  Path Traversal        ../  %2e%2e 등 디렉터리 탈출 패턴
WEB-007  CVE 탐침 경로          .env, /actuator, /.git, /wp-config.php 등
"""
from __future__ import annotations

import re

from redis.asyncio import Redis

from app.common.constants import HONEYPOT_DEMO_PATH, HONEYPOT_PATH_SEVERITY, KillChainStage, RuleId, SignalCategory
from app.models.envelope import NormalizedEvent
from app.models.signal import Signal
from app.redis_kv import keys
from app.workers.detection.rule_settings import get_rule_settings


# ── Patterns ──────────────────────────────────────────────────────────────────

# WEB-001: web-shell upload paths
_WEBSHELL_PATH_RE = re.compile(
    r"/(?:uploads?|files?|media|static|assets?|wp-content/uploads?)"
    r"/[^?\s]*\.(php\d?|jsp|jspx|asp|aspx|cfm|cgi|pl|py|rb|sh)",
    re.IGNORECASE,
)

# WEB-002: admin / sensitive paths
_ADMIN_PATH_RE = re.compile(
    r"^/(?:admin|login|wp-admin|phpmyadmin|manager|console|panel|dashboard|"
    r"administrator|backend|cms|control|cpanel|user/login|account/login)",
    re.IGNORECASE,
)

# WEB-003: automation / scanner User-Agents
_AUTOMATION_UA_RE = re.compile(
    r"(?:curl/|python-requests/|python-urllib/|wget/|scrapy/|"
    r"nikto|sqlmap|nmap|masscan|zgrab|nuclei|dirbuster|gobuster|"
    r"wfuzz|hydra|burpsuite|owasp[-_ ]zap)",
    re.IGNORECASE,
)

# paths that are "abnormal" for WEB-003 (not static assets or root)
_NORMAL_PATH_RE = re.compile(r"^/(?:$|favicon\.ico|robots\.txt|static/|assets/|css/|js/|img/)", re.IGNORECASE)

# WEB-005: SQL Injection 패턴 (URL 디코딩 포함)
_SQLI_RE = re.compile(
    r"(?:"
    r"union\s+(?:all\s+)?select"
    r"|select\s+.+\s+from"
    r"|insert\s+into"
    r"|drop\s+table"
    r"|;\s*(?:select|insert|update|delete|drop|exec)"
    r"|'(?:\s*or\s*'|\s*and\s*'|\s*=\s*'|\s*--)"
    r"|(?:%27|%22)(?:%20|\+)*(?:or|and)(?:%20|\+)"
    r"|(?:0x[0-9a-f]{4,})"          # hex encoding
    r"|\bwaitfor\s+delay\b"
    r"|\bsleep\s*\(\d+\)"
    r"|\bpg_sleep\s*\(\d+\)"
    r")",
    re.IGNORECASE,
)

# WEB-006: Path Traversal / LFI
_PATH_TRAVERSAL_RE = re.compile(
    r"(?:"
    r"(?:\.\./){2,}"                 # ../../
    r"|(?:%2e%2e/){2,}"              # URL-encoded ../../
    r"|(?:%252e%252e/){1,}"          # double-encoded
    r"|/etc/(?:passwd|shadow|hosts|crontab)"
    r"|/proc/self/"
    r"|/windows/system32"
    r"|/boot\.ini"
    r")",
    re.IGNORECASE,
)

# WEB-007: CVE 탐침 / 정보 노출 경로
_CVE_PROBE_RE = re.compile(
    r"^/(?:"
    r"\.env(?:\..*)?$"
    r"|\.git(?:/|$)"
    r"|\.svn(?:/|$)"
    r"|wp-config\.php"
    r"|wp-login\.php"
    r"|xmlrpc\.php"
    r"|actuator(?:/|$)"
    r"|api/swagger(?:\.json|\.yaml|/)"
    r"|api-docs(?:/|$)"
    r"|\.aws/credentials"
    r"|server-status"
    r"|phpinfo\.php"
    r"|config\.php"
    r"|database\.php"
    r"|backup(?:/|\.)"
    r"|shell(?:\.php|$)"
    r"|cmd(?:\.php|$)"
    r"|eval(?:\.php|$)"
    r")",
    re.IGNORECASE,
)


def _event_id(value: object) -> str:
    return value.decode() if isinstance(value, bytes) else str(value)


async def _window_event_ids(redis: Redis, key: str, start: float, end: float) -> list[str]:
    return [_event_id(e) for e in await redis.zrangebyscore(key, start, end)]


def _web_signal(
    rule_id: RuleId,
    event: NormalizedEvent,
    *,
    rule_name: str,
    tactic: str,
    technique: str,
    stage: KillChainStage,
    count: int = 1,
    note: str | None = None,
    triggering_event_ids: list[str] | None = None,
) -> Signal:
    return Signal(
        tenant_id=event.tenant_id,
        asset_id=event.asset_id,
        rule_id=rule_id,
        rule_name=rule_name,
        mitre_tactic=tactic,
        mitre_technique=technique,
        kill_chain_stage=stage,
        source_ip=event.source_ip,
        username=event.username,
        user_agent=event.user_agent,
        detected_count=count,
        detected_at=event.timestamp,
        triggering_event_ids=triggering_event_ids or [event.event_id],
        notes=note,
        escalate_to_incident=True,
    )




def _match_honeypot_path(path: str) -> str | None:
    """경로별 Severity 반환 (설계서 Table 6). 매핑 없으면 None."""
    clean = path.split("?")[0].rstrip("/") or "/"
    if clean in HONEYPOT_PATH_SEVERITY:
        return HONEYPOT_PATH_SEVERITY[clean]
    for prefix, sev in HONEYPOT_PATH_SEVERITY.items():
        if clean.startswith(prefix + "/"):
            return sev
    return None


async def evaluate_honeypot(redis: Redis, event: NormalizedEvent) -> Signal | None:
    """WEB-HNY-001 — Honeypot 경로 접근 탐지 (설계서 6.5).

    /demo        → Info,   Demo Signal  (Incident 승격 안 함)
    /.env        → High,   Threat Signal
    /wp-login.php → Medium, Threat Signal
    /phpmyadmin  → High,   Threat Signal
    """
    if not event.request_path:
        return None

    severity = _match_honeypot_path(event.request_path)
    if severity is None:
        return None

    is_demo_path = event.request_path.split("?")[0].rstrip("/") == HONEYPOT_DEMO_PATH
    category = SignalCategory.DEMO if is_demo_path else SignalCategory.THREAT

    return Signal(
        tenant_id=event.tenant_id,
        asset_id=event.asset_id,
        rule_id=RuleId.WEB_HONEYPOT,
        rule_name="Honeypot Path Access",
        mitre_tactic="Reconnaissance" if severity in ("info", "medium") else "Initial Access",
        mitre_technique="T1595" if severity in ("info", "medium") else "T1190",
        kill_chain_stage=KillChainStage.RECONNAISSANCE,
        source_ip=event.source_ip,
        user_agent=event.user_agent,
        detected_count=1,
        detected_at=event.timestamp,
        triggering_event_ids=[event.event_id],
        notes=f"Honeypot path accessed: {event.request_path} (severity={severity})",
        escalate_to_incident=(category == SignalCategory.THREAT),
        category=category,
        is_demo=is_demo_path,
    )

async def evaluate_web_rules(redis: Redis, event: NormalizedEvent) -> list[Signal]:
    """Evaluate WEB-001..007 rules for a WEB_REQUEST event."""
    signals: list[Signal] = []
    if not event.source_ip or not event.request_path:
        return signals

    cfg = await get_rule_settings(redis, event.tenant_id)
    now_score = event.timestamp.timestamp()
    path = event.request_path
    status = event.status_code or 0
    ua = event.user_agent or ""

    # ── WEB-001: Web Shell Access ─────────────────────────────────────────────
    if status == 200 and _WEBSHELL_PATH_RE.search(path):
        signals.append(_web_signal(
            RuleId.WEB_SHELL_ACCESS, event,
            rule_name="Web Shell Access",
            tactic="Persistence",
            technique="T1505.003",
            stage=KillChainStage.EXECUTION,
            note=f"Possible web shell accessed: {path} (HTTP 200).",
        ))

    # ── WEB-002: Admin Path Scan ──────────────────────────────────────────────
    if _ADMIN_PATH_RE.match(path):
        admin_key = keys.web_admin_req(event.tenant_id, event.asset_id, event.source_ip)
        admin_window = cfg.web_admin_scan_window_seconds
        admin_threshold = cfg.web_admin_scan_threshold
        await redis.zadd(admin_key, {event.event_id: now_score})
        await redis.zremrangebyscore(admin_key, 0, now_score - admin_window)
        await redis.expire(admin_key, admin_window * 2)
        admin_count = int(await redis.zcard(admin_key))
        if admin_count >= admin_threshold:
            triggering = await _window_event_ids(redis, admin_key, now_score - admin_window, now_score)
            signals.append(_web_signal(
                RuleId.WEB_ADMIN_SCAN, event,
                rule_name="Admin Path Scan",
                tactic="Reconnaissance",
                technique="T1595",
                stage=KillChainStage.RECONNAISSANCE,
                count=admin_count,
                note=f"{admin_threshold}+ admin/login path hits from one IP in {admin_window}s.",
                triggering_event_ids=triggering,
            ))

    # ── WEB-003: Automation Tool Access ──────────────────────────────────────
    if _AUTOMATION_UA_RE.search(ua) and not _NORMAL_PATH_RE.match(path):
        signals.append(_web_signal(
            RuleId.WEB_AUTOMATION, event,
            rule_name="Automation Tool Access",
            tactic="Initial Access",
            technique="T1190",
            stage=KillChainStage.RECONNAISSANCE,
            note=f"Automation UA detected: {ua[:80]} on path {path}.",
        ))

    # ── WEB-004: 404 Burst ────────────────────────────────────────────────────
    if status == 404:
        burst_key = keys.web_404(event.tenant_id, event.asset_id, event.source_ip)
        burst_window = cfg.web_404_window_seconds
        burst_threshold = cfg.web_404_threshold
        await redis.zadd(burst_key, {event.event_id: now_score})
        await redis.zremrangebyscore(burst_key, 0, now_score - burst_window)
        await redis.expire(burst_key, burst_window * 2)
        burst_count = int(await redis.zcard(burst_key))
        if burst_count >= burst_threshold:
            triggering = await _window_event_ids(redis, burst_key, now_score - burst_window, now_score)
            signals.append(_web_signal(
                RuleId.WEB_404_BURST, event,
                rule_name="404 Burst",
                tactic="Reconnaissance",
                technique="T1595",
                stage=KillChainStage.RECONNAISSANCE,
                count=burst_count,
                note=f"{burst_threshold}+ 404 responses from one IP in {burst_window}s.",
                triggering_event_ids=triggering,
            ))

    # ── WEB-005: SQL Injection ────────────────────────────────────────────────
    if cfg.web_sql_injection_enabled:
        full_url = event.request_path
        if _SQLI_RE.search(full_url):
            signals.append(_web_signal(
                RuleId.WEB_SQL_INJECTION, event,
                rule_name="SQL Injection Attempt",
                tactic="Initial Access",
                technique="T1190",
                stage=KillChainStage.INITIAL_ACCESS,
                note=f"SQL injection pattern detected: {full_url[:120]}",
            ))

    # ── WEB-006: Path Traversal / LFI ────────────────────────────────────────
    if cfg.web_path_traversal_enabled:
        if _PATH_TRAVERSAL_RE.search(event.request_path):
            signals.append(_web_signal(
                RuleId.WEB_PATH_TRAVERSAL, event,
                rule_name="Path Traversal / LFI",
                tactic="Discovery",
                technique="T1083",
                stage=KillChainStage.RECONNAISSANCE,
                note=f"Directory traversal pattern detected: {event.request_path[:120]}",
            ))

    # ── WEB-007: CVE 탐침 경로 접근 ──────────────────────────────────────────
    if cfg.web_cve_probe_enabled:
        probe_path = event.request_path.split("?")[0]
        if _CVE_PROBE_RE.match(probe_path):
            signals.append(_web_signal(
                RuleId.WEB_CVE_PROBE, event,
                rule_name="CVE Probe Path Access",
                tactic="Reconnaissance",
                technique="T1595.002",
                stage=KillChainStage.RECONNAISSANCE,
                note=f"Sensitive/CVE probe path accessed: {probe_path}",
            ))

    # WEB-HNY-001: Honeypot 경로 접근 탐지
    honeypot_signal = await evaluate_honeypot(redis, event)
    if honeypot_signal:
        signals.append(honeypot_signal)

    return signals


async def evaluate_net_rules(redis: Redis, event: NormalizedEvent) -> list[Signal]:
    """NET-001 HTTP Flood 탐지 (설계서 3.1).

    5분 내 동일 IP에서 임계값 이상의 HTTP 요청 → NET-001 Signal 생성.
    Sliding Window (Redis Sorted Set) 방식으로 정확한 윈도우 계산.
    """
    signals: list[Signal] = []
    if not event.source_ip:
        return signals

    cfg = await get_rule_settings(redis, event.tenant_id)
    if not cfg.net_http_flood_enabled:
        return signals

    now_score = event.timestamp.timestamp()
    flood_key = keys.net_rate_ip(event.tenant_id, event.asset_id, event.source_ip)
    flood_window = cfg.net_http_flood_window_seconds
    flood_threshold = cfg.net_http_flood_threshold

    await redis.zadd(flood_key, {event.event_id: now_score})
    await redis.zremrangebyscore(flood_key, 0, now_score - flood_window)
    await redis.expire(flood_key, flood_window * 2)
    flood_count = int(await redis.zcard(flood_key))

    if flood_count >= flood_threshold:
        triggering = await _window_event_ids(redis, flood_key, now_score - flood_window, now_score)
        signals.append(_web_signal(
            RuleId.NET_HTTP_FLOOD, event,
            rule_name="HTTP Flood",
            tactic="Impact",
            technique="T1595",
            stage=KillChainStage.RECONNAISSANCE,
            count=flood_count,
            note=(
                f"HTTP Flood detected: {flood_count} requests from {event.source_ip} "
                f"in {flood_window}s (threshold={flood_threshold})."
            ),
            triggering_event_ids=triggering[:50],  # 최대 50개로 제한
        ))

    return signals
