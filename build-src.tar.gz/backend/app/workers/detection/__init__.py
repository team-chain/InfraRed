"""Detection worker package."""
