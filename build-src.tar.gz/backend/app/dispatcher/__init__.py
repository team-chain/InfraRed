"""Alert dispatcher package."""
