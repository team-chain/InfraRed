import boto3
import os
import logging
from datetime import datetime, timezone

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    """
    step-ca Docker 볼륨을 EC2 SSM으로 tar 압축 후 S3에 업로드.
    설계서 §4.2: 주 1회 암호화 백업.
    Lambda + S3 소용량 → 프리티어 완전 무료.
    """
    ssm         = boto3.client("ssm")
    instance_id = os.environ["EC2_INSTANCE_ID"]
    s3_bucket   = os.environ["S3_BUCKET"]
    timestamp   = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    s3_key      = f"backups/step-ca/{timestamp}.tar.gz"
    tmp_path    = f"/tmp/step-ca-backup-{timestamp}.tar.gz"

    # SSM으로 EC2에서 step-ca 볼륨을 tar 압축 후 S3 직접 업로드
    cmd = " && ".join([
        f"docker run --rm -v step-ca-data:/mnt/step-ca:ro -v /tmp:/tmp alpine tar czf {tmp_path} -C /mnt/step-ca .",
        f"aws s3 cp {tmp_path} s3://{s3_bucket}/{s3_key}",
        f"rm -f {tmp_path}",
    ])

    response = ssm.send_command(
        InstanceIds=[instance_id],
        DocumentName="AWS-RunShellScript",
        Parameters={"commands": [cmd]},
    )
    command_id = response["Command"]["CommandId"]
    logger.info(f"step-ca backup sent: command_id={command_id}, s3_key={s3_key}")
    return {"status": "ok", "command_id": command_id, "s3_key": s3_key}
